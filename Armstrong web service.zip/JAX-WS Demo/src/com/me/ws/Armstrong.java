package com.me.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "com.me.ws.ArmstrongService")
public class Armstrong{
	
	public int numberOfDigits(int number) {
		int countOfDigits = 0;
		while(number>0) {
			countOfDigits++;
			number /= 10;
		}
		return countOfDigits;
	}

	public boolean isArmstrong(int number) {
		int sumOfDigits = 0;
		int numCopy = number;
		int countDigits = numberOfDigits(number);
		while(numCopy>0) {
			int lastDigit = numCopy%10;
			sumOfDigits += (int)Math.pow(lastDigit, countDigits);
			numCopy /= 10;
		}
		return number==sumOfDigits;
	}
}