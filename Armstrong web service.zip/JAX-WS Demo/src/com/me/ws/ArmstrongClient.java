package com.me.ws;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class ArmstrongClient {

	public static void main(String[] args) throws Exception{
		URL url = new URL("http://127.0.0.1:6800/myself?wsdl");
		
		QName qname = new QName("http://ws.me.com/","ArmstrongService");
		
		Service service = Service.create(url, qname);
		
		ArmstrongService endPoint = service.getPort(ArmstrongService.class);
		
		Scanner scInput = new Scanner(System.in);
		
		int num = 0 ;
		
		System.out.print("Enter the number: ");
		num = Integer.parseInt(scInput.nextLine());
		
		if(endPoint.isArmstrong(num)) {
			System.out.println("Number is armstrong");
		}
		else {
			System.out.println("Number is not armstrong");
		}
		
		scInput.close();
	}
}